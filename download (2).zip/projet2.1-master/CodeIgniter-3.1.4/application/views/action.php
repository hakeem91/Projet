<!DOCTYPE html>
<html>
<head>
	<title>Accueil</title>
</head>
<body>
<FORM method="Post" action="equipe.php" >
<INPUT TYPE="submit" NAME="creer" VALUE="creer equipe">                                                       
</FORM>
<FORM method="Post" action="rejoindre.php" >
<INPUT TYPE="submit" NAME="rejoindre" VALUE="Rejoindre equipe">                                                       
</FORM>
  <FORM method="Post" action="ajouter.php" >
<INPUT TYPE="submit" NAME="ajouter" VALUE="Ajouter evenement">                                                       
</FORM>
   
    
    
<?php
 //if (isset($_POST['OK']) 
   
	?>
</body>
  </html>






