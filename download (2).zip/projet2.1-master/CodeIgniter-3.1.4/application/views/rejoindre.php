<!DOCTYPE html>
<html>
<head>
	<title>Accueil</title>
</head>
<body>
<form action="action.php" method="post">

  <p> Mot de passe : <input type="password" name="password_equipe" /></p>
   
 <p><input type="submit" value="OK"></p>
</form>
  
  

</body>
</html>