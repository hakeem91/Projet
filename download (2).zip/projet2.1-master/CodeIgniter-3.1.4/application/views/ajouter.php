
<!DOCTYPE html>
<html>
<head>
	<title>Accueil</title>
</head>
<body>
<form action="action.php" method="post">
 
<p>Type : <input type="text" name="type" /></p>
  <p> Date Debut <input type="date_d" name="debut"/></p>
  <p> Date Fin <input type="date_f" name="fin"/></p>
 
   <p>Lieu: <input type="text" name="Lieu" /></p>
   
  <TEXTAREA name="Description_ajout" rows=4 cols=40 onkeyup="toto(this);">Description du Sport</TEXTAREA>
 <p><input type="submit" value="OK" ></p>
     
</form>
  
  <script>
function toto(c){
if(c.value == "" )
 document.getElementById("sub" ).disabled = true;
else
 document.getElementById("sub" ).disabled = false;
}
</script>

</body>
</html>