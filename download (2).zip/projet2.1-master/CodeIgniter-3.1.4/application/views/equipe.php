<!DOCTYPE html>
<html>
<head>
	<title>Accueil</title>
</head>
<body>
<form action="action.php" method="post">
 <p>Nom : <input type="text" name="login" /></p>
  <p> Mot de passe : <input type="password" name="password" /></p>
    <p>Sports: <input type="text" name="sports" /></p>
   <p>Ville: <input type="text" name="ville" /></p>
  <TEXTAREA name="nom" rows=4 cols=40>Description du Sport</TEXTAREA>
  
  <p>Logo : <input type="file" name="icone" id="icone" /></p>
  <p>Photo : <input type="file" name="photo" id="photo" /></p>
 
 <p><input type="submit" value="OK"></p>
</form>
  
  

</body>
</html>