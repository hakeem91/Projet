<!DOCTYPE html>
<html>
<head>
	<title>Accueil</title>
</head>
<body>

<p>Bienvenue sur la page d'accueil de votre club.</p>
	<p>
		Connexion à votre compte.
	</p>
	
	<form action="application/views/action.php" method="post">
 <p>Votre login : <input type="text" name="login" /></p>
 <p>Votre mot de passe : <input type="password" name="password" /></p>
 <p><input type="submit" value="OK"></p>
</form>

</body>
</html>
